import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const UberDriverApp());
}

class UberDriverApp extends StatelessWidget {
  const UberDriverApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RideNow - Driver',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: const HomeScreen(),
    );
  }
}
